//
//  FeedBackAttachmentPreviewController.h
//  feedback
//
//  Created by 李焱 on 2021/3/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FeedBackAttachmentPreviewController : UIViewController

@property(nonatomic, strong) UIImage *image;

@end

NS_ASSUME_NONNULL_END
